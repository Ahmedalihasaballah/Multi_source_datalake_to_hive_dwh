"""Job 1 - read the 3 raw sources from the HDFS landing dir, clean + conform them,
and load them into Hive staging tables:
    staging.stg_customers, staging.stg_products, staging.stg_sales (POS + ecommerce unified)
    staging.rej_sales  (rejected rows with a reason)
"""
import argparse
from pyspark.sql import functions as F
from common import get_spark, save_table

ap = argparse.ArgumentParser()
ap.add_argument("--landing", required=True)
ap.add_argument("--staging-db", default="staging")
args = ap.parse_args()
L, DB = args.landing, args.staging_db

spark = get_spark("lake_clean_transform")
spark.sql(f"CREATE DATABASE IF NOT EXISTS {DB}")


def clean_str(c):
    return F.nullif(F.trim(F.col(c)), F.lit(""))


# ------------------------------------------------------------------ CRM (source 3)
customers = (spark.read.option("header", "true").csv(f"{L}/crm/*.csv")
    .select(
        F.col("customer_id").cast("long").alias("customer_id"),
        F.initcap(clean_str("full_name")).alias("full_name"),
        F.lower(clean_str("email")).alias("email"),
        clean_str("phone").alias("phone"),
        F.upper(clean_str("gender")).alias("gender"),
        F.to_date("birth_date").alias("birth_date"),
        F.initcap(clean_str("city")).alias("city"),
        F.upper(clean_str("country")).alias("country"),
        F.to_date("signup_date").alias("signup_date"))
    .filter(F.col("customer_id").isNotNull())
    .dropDuplicates(["customer_id"]))
save_table(customers, f"{DB}.stg_customers")

products = (spark.read.parquet(f"{L}/crm/*.parquet")
    .select(
        F.upper(F.trim("sku")).alias("sku"),
        F.trim("product_name").alias("product_name"),
        F.initcap(F.trim("category")).alias("category"),
        F.initcap(F.trim("brand")).alias("brand"),
        F.col("list_price").cast("decimal(12,2)").alias("list_price"),
        F.col("cost_price").cast("decimal(12,2)").alias("cost_price"))
    .filter(F.col("sku").isNotNull())
    .dropDuplicates(["sku"]))
save_table(products, f"{DB}.stg_products")

# ------------------------------------------------------------------ POS (source 1, CSV)
pos_raw = spark.read.option("header", "true").csv(f"{L}/pos/*.csv")
pos = pos_raw.select(
    F.concat(F.lit("POS-"), F.trim("transaction_id")).alias("sale_id"),
    F.lit("STORE").alias("channel"),
    F.col("store_id").cast("int").alias("store_id"),
    F.initcap(clean_str("store_name")).alias("store_name"),
    F.initcap(clean_str("city")).alias("store_city"),
    F.to_timestamp("sale_ts").alias("order_ts"),
    F.upper(F.trim("product_sku")).alias("sku"),
    F.col("customer_id").cast("long").alias("customer_id"),
    F.col("quantity").cast("int").alias("quantity"),
    F.col("unit_price").cast("decimal(12,2)").alias("unit_price"),
    (F.coalesce(F.col("discount_pct").cast("double"), F.lit(0.0)) / 100.0).alias("_disc_rate"),
    F.upper(F.trim("payment_method")).alias("payment_method"),
).withColumn("discount_amount",
             F.round(F.col("quantity") * F.col("unit_price") * F.col("_disc_rate"), 2).cast("decimal(12,2)")
).drop("_disc_rate")

# ------------------------------------------------------------------ E-commerce (source 2, Parquet)
# guest checkouts have no customer_id -> resolve through the CRM e-mail
email_map = customers.select(F.col("email").alias("_email"), F.col("customer_id").alias("_cid"))
ecom_raw = spark.read.parquet(f"{L}/ecom/*.parquet")
ecom = (ecom_raw
    .withColumn("_email", F.lower(F.trim("customer_email")))
    .join(F.broadcast(email_map), "_email", "left")
    .select(
        F.concat(F.lit("WEB-"), F.trim("order_id")).alias("sale_id"),
        F.lit("WEB").alias("channel"),
        F.lit(0).alias("store_id"),
        F.lit("Online").alias("store_name"),
        F.lit("Online").alias("store_city"),
        F.col("order_ts").cast("timestamp").alias("order_ts"),
        F.upper(F.trim("sku")).alias("sku"),
        F.coalesce(F.col("customer_id").cast("long"), F.col("_cid")).alias("customer_id"),
        F.col("qty").cast("int").alias("quantity"),
        F.col("price").cast("decimal(12,2)").alias("unit_price"),
        F.col("discount_amount").cast("decimal(12,2)").alias("discount_amount"),
        F.upper(F.trim("payment_method")).alias("payment_method")))

# ------------------------------------------------------------------ Unify + validate
unified = pos.unionByName(ecom).dropDuplicates(["sale_id"])
is_valid = (F.col("quantity") > 0) & (F.col("unit_price") > 0) & F.col("order_ts").isNotNull() & F.col("sku").isNotNull()

rejected = (unified.filter(~is_valid)
            .withColumn("reject_reason", F.lit("invalid quantity/price/timestamp/sku")))
save_table(rejected, f"{DB}.rej_sales")

sales = (unified.filter(is_valid)
    .withColumn("gross_amount", (F.col("quantity") * F.col("unit_price")).cast("decimal(14,2)"))
    .withColumn("net_amount", (F.col("gross_amount") - F.col("discount_amount")).cast("decimal(14,2)")))
save_table(sales, f"{DB}.stg_sales")

spark.stop()
