from pyspark.sql import SparkSession


def get_spark(app_name: str) -> SparkSession:
    """SparkSession with Hive metastore support."""
    return (SparkSession.builder.appName(app_name)
            .enableHiveSupport()
            .config("spark.sql.sources.partitionOverwriteMode", "dynamic")
            .getOrCreate())


def save_table(df, table: str, partition_by=None):
    """Overwrite a Hive-managed Parquet table."""
    w = df.write.mode("overwrite").format("parquet")
    if partition_by:
        w = w.partitionBy(*partition_by)
    w.saveAsTable(table)
    print(f"[saved] {table}: {df.sparkSession.table(table).count()} rows")
