"""Job 2 - model the staging data into a star schema in Hive (database dw):
    dim_date, dim_customer, dim_product, dim_store, dim_channel, fact_sales
"""
import argparse
from pyspark.sql import functions as F, Window
from common import get_spark, save_table

ap = argparse.ArgumentParser()
ap.add_argument("--staging-db", default="staging")
ap.add_argument("--dw-db", default="dw")
args = ap.parse_args()
S, DW = args.staging_db, args.dw_db

spark = get_spark("lake_build_warehouse")
spark.sql(f"CREATE DATABASE IF NOT EXISTS {DW}")

sales = spark.table(f"{S}.stg_sales")
customers = spark.table(f"{S}.stg_customers")
products = spark.table(f"{S}.stg_products")

# ---------------------------------------------------------------- dim_date
lo, hi = sales.agg(F.min(F.to_date("order_ts")), F.max(F.to_date("order_ts"))).first()
dim_date = (spark.sql(f"SELECT explode(sequence(to_date('{lo}'), to_date('{hi}'), interval 1 day)) AS full_date")
    .select(
        F.date_format("full_date", "yyyyMMdd").cast("int").alias("date_key"),
        "full_date",
        F.year("full_date").alias("year"),
        F.quarter("full_date").alias("quarter"),
        F.month("full_date").alias("month"),
        F.date_format("full_date", "MMMM").alias("month_name"),
        F.dayofmonth("full_date").alias("day"),
        F.dayofweek("full_date").alias("day_of_week"),
        F.date_format("full_date", "EEEE").alias("day_name"),
        F.dayofweek("full_date").isin(6, 7).alias("is_weekend")))   # Fri/Sat weekend (Egypt)
save_table(dim_date, f"{DW}.dim_date")

# ---------------------------------------------------------------- dim_channel
dim_channel = spark.createDataFrame([(1, "STORE"), (2, "WEB")], ["channel_key", "channel_name"])
save_table(dim_channel, f"{DW}.dim_channel")

# ---------------------------------------------------------------- dim_store (key 0 = Online)
dim_store = (sales.select(F.col("store_id").alias("store_key"), "store_name",
                          F.col("store_city").alias("city"))
    .dropDuplicates(["store_key"])
    .withColumn("store_type", F.when(F.col("store_key") == 0, "ONLINE").otherwise("PHYSICAL")))
save_table(dim_store, f"{DW}.dim_store")

# ---------------------------------------------------------------- dim_product
dim_product = (products.withColumn("product_key", F.row_number().over(Window.orderBy("sku")))
    .select("product_key", "sku", "product_name", "category", "brand", "list_price", "cost_price"))
save_table(dim_product, f"{DW}.dim_product")

# ---------------------------------------------------------------- dim_customer (key -1 = Unknown)
dim_customer = (customers.withColumn("customer_key", F.row_number().over(Window.orderBy("customer_id")))
    .select("customer_key", "customer_id", "full_name", "email", "phone", "gender",
            "birth_date", "city", "country", "signup_date"))
unknown = spark.createDataFrame(
    [(-1, None, "Unknown", None, None, None, None, None, None, None)],
    schema=dim_customer.schema)
save_table(dim_customer.unionByName(unknown), f"{DW}.dim_customer")

# ---------------------------------------------------------------- fact_sales
dp = spark.table(f"{DW}.dim_product").select("product_key", "sku", "cost_price")
dc = spark.table(f"{DW}.dim_customer").select("customer_key", "customer_id")

joined = (sales.join(dp, "sku", "left").join(dc, "customer_id", "left"))

orphans = joined.filter(F.col("product_key").isNull())          # SKU not in CRM catalogue
save_table(orphans.drop("product_key", "cost_price", "customer_key"), f"{S}.rej_sales_no_product")

fact = (joined.filter(F.col("product_key").isNotNull())
    .select(
        "sale_id",
        F.date_format("order_ts", "yyyyMMdd").cast("int").alias("date_key"),
        F.coalesce("customer_key", F.lit(-1)).alias("customer_key"),
        "product_key",
        F.col("store_id").alias("store_key"),
        F.when(F.col("channel") == "STORE", 1).otherwise(2).alias("channel_key"),
        "order_ts", "quantity", "unit_price", "gross_amount", "discount_amount", "net_amount",
        (F.col("quantity") * F.col("cost_price")).cast("decimal(14,2)").alias("cost_amount"),
        (F.col("net_amount") - F.col("quantity") * F.col("cost_price")).cast("decimal(14,2)").alias("margin_amount"),
        "payment_method",
        F.year("order_ts").alias("sale_year")))
save_table(fact, f"{DW}.fact_sales", partition_by=["sale_year"])

spark.stop()
