#!/usr/bin/env bash
# Runs the two PySpark jobs: (1) clean/transform -> staging, (2) build star schema -> dw
set -euo pipefail
source "$(dirname "$0")/../config/pipeline.env"
J="$PROJECT_HOME/spark_jobs"

echo ">> Job 1: clean & transform (landing -> Hive staging)"
spark-submit --master "$SPARK_MASTER" $SPARK_OPTS --py-files "$J/common.py" \
  "$J/clean_transform.py" --landing "$HDFS_LANDING" --staging-db "$STAGING_DB"

echo ">> Job 2: build star schema (staging -> Hive dw)"
spark-submit --master "$SPARK_MASTER" $SPARK_OPTS --py-files "$J/common.py" \
  "$J/build_warehouse.py" --staging-db "$STAGING_DB" --dw-db "$DW_DB"
