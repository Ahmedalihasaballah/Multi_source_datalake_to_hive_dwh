#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/../config/pipeline.env"
hive -f "$PROJECT_HOME/sql/01_create_databases.sql" \
     --hivevar STAGING_DB="$STAGING_DB" --hivevar DW_DB="$DW_DB" \
     --hivevar WAREHOUSE_DIR="$HDFS_WAREHOUSE"
