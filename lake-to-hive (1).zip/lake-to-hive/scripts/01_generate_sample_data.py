#!/usr/bin/env python3
"""Generate 3 heterogeneous sources (with deliberate dirt) for the pipeline.

 source_1_pos        CSV      store sales transactions
 source_2_ecommerce  Parquet  online order lines
 source_3_crm        CSV + Parquet   customers.csv + products.parquet (master data)
"""
import argparse, os
import numpy as np
import pandas as pd

p = argparse.ArgumentParser()
p.add_argument("--out", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data"))
p.add_argument("--pos-rows", type=int, default=200_000)
p.add_argument("--ecom-rows", type=int, default=120_000)
p.add_argument("--customers", type=int, default=5_000)
p.add_argument("--products", type=int, default=300)
p.add_argument("--seed", type=int, default=42)
a = p.parse_args()

rng = np.random.default_rng(a.seed)
out = os.path.abspath(a.out)
d1, d2, d3 = (os.path.join(out, x) for x in ("source_1_pos", "source_2_ecommerce", "source_3_crm"))
for d in (d1, d2, d3):
    os.makedirs(d, exist_ok=True)

START, DAYS = pd.Timestamp("2025-01-01"), 638  # through ~2026-09-30
def split(df, parts):
    size = -(-len(df) // parts)
    return [df.iloc[i:i + size] for i in range(0, len(df), size)]


def rand_ts(n):
    return pd.Series(START + pd.to_timedelta(rng.integers(0, DAYS * 86400, n), unit="s"))

# ---------------- Source 3: CRM master data ----------------
cats = ["Electronics", "Home", "Fashion", "Sports", "Beauty", "Grocery"]
brands = ["Acme", "Nile", "Delta", "Orion", "Pyramid", "Zenith"]
products = pd.DataFrame({
    "sku": [f"SKU{i:04d}" for i in range(1, a.products + 1)],
    "product_name": [f"Product {i}" for i in range(1, a.products + 1)],
    "category": rng.choice(cats, a.products),
    "brand": rng.choice(brands, a.products),
})
products["list_price"] = np.round(rng.uniform(5, 500, a.products), 2)
products["cost_price"] = np.round(products["list_price"] * rng.uniform(0.5, 0.8, a.products), 2)
products.to_parquet(os.path.join(d3, "products.parquet"), index=False)

n = a.customers
cities = ["Cairo", "Giza", "Alexandria", "Dubai", "Riyadh", "Amman"]
cust = pd.DataFrame({
    "customer_id": np.arange(1, n + 1),
    "full_name": [f"Customer {i}" for i in range(1, n + 1)],
    "email": [f"user{i}@example.com" for i in range(1, n + 1)],
    "phone": [f"+20100{rng.integers(1000000, 9999999)}" for _ in range(n)],
    "gender": rng.choice(["M", "F", "m", "f", None], n),
    "birth_date": (pd.Timestamp("1960-01-01") + pd.to_timedelta(rng.integers(0, 15000, n), unit="D")).strftime("%Y-%m-%d"),
    "city": rng.choice(cities, n),
    "country": rng.choice(["EG", "AE", "SA", "JO"], n),
    "signup_date": (START - pd.to_timedelta(rng.integers(1, 900, n), unit="D")).strftime("%Y-%m-%d"),
})
idx = rng.choice(n, n // 10, replace=False)   # dirt: padded/uppercase emails
cust.loc[idx, "email"] = "  " + cust.loc[idx, "email"].str.upper() + " "
cust = pd.concat([cust, cust.sample(frac=0.02, random_state=1)], ignore_index=True)  # 2% duplicates
cust.to_csv(os.path.join(d3, "customers.csv"), index=False)

# ---------------- Source 1: POS CSV ----------------
stores = {1: ("Cairo Mall", "Cairo"), 2: ("Giza Plaza", "Giza"), 3: ("Alex Corniche", "Alexandria"),
          4: ("Dubai Marina", "Dubai"), 5: ("Riyadh Park", "Riyadh"), 6: ("Amman Boulevard", "Amman")}
m = a.pos_rows
sid = rng.integers(1, len(stores) + 1, m)
sku_idx = rng.integers(0, a.products, m)
cust_ids = pd.array(rng.integers(1, n + 1, m), dtype="Int64")
cust_ids[rng.random(m) < 0.4] = pd.NA
pos = pd.DataFrame({
    "transaction_id": [f"POS-{i:09d}" for i in range(1, m + 1)],
    "store_id": sid,
    "store_name": [stores[s][0].upper() if i % 7 == 0 else stores[s][0] for i, s in enumerate(sid)],
    "city": [stores[s][1].lower() if i % 11 == 0 else stores[s][1] for i, s in enumerate(sid)],
    "sale_ts": rand_ts(m).dt.strftime("%Y-%m-%d %H:%M:%S"),
    "product_sku": [products.sku[i] if k % 13 else " " + products.sku[i].lower() + " " for k, i in enumerate(sku_idx)],
    "quantity": rng.integers(1, 6, m),
    "unit_price": np.round(products.list_price.values[sku_idx] * rng.uniform(0.95, 1.05, m), 2),
    "discount_pct": rng.choice([0, 0, 0, 5, 10, 15, np.nan], m),
    "customer_id": cust_ids,
    "payment_method": rng.choice(["cash", "CARD", "Card ", "wallet"], m),
})
pos.loc[rng.choice(m, max(1, m // 200), replace=False), "quantity"] = -1          # invalid qty
pos = pd.concat([pos, pos.sample(frac=0.01, random_state=2)], ignore_index=True)  # duplicates
for i, chunk in enumerate(split(pos, 3), start=1):
    chunk.to_csv(os.path.join(d1, f"pos_sales_part{i}.csv"), index=False)

# ---------------- Source 2: E-commerce Parquet ----------------
e = a.ecom_rows
sku_idx = rng.integers(0, a.products, e)
cid = rng.integers(1, n + 1, e).astype("float")
guest = rng.random(e) < 0.3                       # guest checkout: customer_id missing, only email known
emails = np.array([f"USER{x}@Example.com" for x in rng.integers(1, n + 1, e)], dtype=object)
cid_series = pd.Series(cid).mask(guest)
emails = np.where(~guest, [f"USER{int(c)}@Example.com" if c == c else "" for c in cid], emails)
ecom = pd.DataFrame({
    "order_id": [f"WEB-{i:09d}" for i in range(1, e + 1)],
    "order_ts": rand_ts(e),
    "customer_id": cid_series,
    "customer_email": emails,
    "sku": products.sku.values[sku_idx],
    "qty": rng.integers(1, 5, e),
    "price": np.round(products.list_price.values[sku_idx] * rng.uniform(0.9, 1.0, e), 2),
    "discount_amount": np.round(rng.choice([0, 0, 2.5, 5, 10], e), 2),
    "payment_method": rng.choice(["CARD", "PAYPAL", "WALLET", "COD"], e),
    "shipping_country": rng.choice(["EG", "AE", "SA", "JO"], e),
})
ecom = pd.concat([ecom, ecom.sample(frac=0.01, random_state=3)], ignore_index=True)
for i, chunk in enumerate(split(ecom, 2), start=1):
    chunk.to_parquet(os.path.join(d2, f"ecom_orders_part{i}.parquet"), index=False,
                     coerce_timestamps="ms", allow_truncated_timestamps=True)

print(f"Generated sources under {out}")
for d in (d1, d2, d3):
    print(" ", os.path.basename(d), sorted(os.listdir(d)))
