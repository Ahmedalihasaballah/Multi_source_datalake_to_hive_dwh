#!/usr/bin/env bash
# Consolidate CSV + Parquet files from the 3 source dirs into ONE HDFS landing directory.
set -euo pipefail
source "$(dirname "$0")/../config/pipeline.env"
shopt -s nullglob

load() {  # $1=landing sub-folder  $2=local source dir
  local name="$1" dir="$2"
  local files=("$dir"/*.csv "$dir"/*.parquet)
  [ "${#files[@]}" -gt 0 ] || { echo "ERROR: no csv/parquet files in $dir"; exit 1; }
  hdfs dfs -mkdir -p "$HDFS_LANDING/$name"
  hdfs dfs -put -f "${files[@]}" "$HDFS_LANDING/$name/"
  echo "[landed] $name  (${#files[@]} files)  <- $dir"
}

hdfs dfs -mkdir -p "$HDFS_LANDING" "$HDFS_WAREHOUSE"
load pos  "$SRC1_DIR"
load ecom "$SRC2_DIR"
load crm  "$SRC3_DIR"

echo ">> Landing directory content:"
hdfs dfs -ls -R -h "$HDFS_LANDING"
