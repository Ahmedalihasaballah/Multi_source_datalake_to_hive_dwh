#!/usr/bin/env bash
# End-to-end run.  Usage: scripts/run_all.sh [--skip-generate]
set -euo pipefail
cd "$(dirname "$0")"
./00_check_env.sh
[ "${1:-}" = "--skip-generate" ] || python3 01_generate_sample_data.py
./02_consolidate_to_hdfs.sh
./03_create_hive_dbs.sh
./04_run_etl.sh
./05_validate.sh
echo "Pipeline finished successfully."
