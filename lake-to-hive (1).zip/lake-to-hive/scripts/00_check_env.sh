#!/usr/bin/env bash
# Verifies the Linux Hadoop environment and installs python deps for data generation.
set -euo pipefail
source "$(dirname "$0")/../config/pipeline.env"

ok=1
for bin in java hdfs hive spark-submit python3; do
  if command -v "$bin" >/dev/null 2>&1; then echo "[OK]   $bin -> $(command -v $bin)"
  else echo "[MISS] $bin not found in PATH"; ok=0; fi
done
[ "$ok" -eq 1 ] || { echo "Install/export the missing tools (JAVA_HOME, HADOOP_HOME, HIVE_HOME, SPARK_HOME)."; exit 1; }

echo ">> HDFS status"; hdfs dfsadmin -report | head -n 8 || { echo "HDFS not reachable - run start-dfs.sh"; exit 1; }
echo ">> Python deps"; python3 -m pip install --user -r "$PROJECT_HOME/requirements.txt"
echo "Environment OK."
