SELECT 'stg_sales' t, COUNT(*) n FROM ${hivevar:STAGING_DB}.stg_sales
UNION ALL SELECT 'fact_sales', COUNT(*) FROM ${hivevar:DW_DB}.fact_sales
UNION ALL SELECT 'dim_customer', COUNT(*) FROM ${hivevar:DW_DB}.dim_customer
UNION ALL SELECT 'dim_product', COUNT(*) FROM ${hivevar:DW_DB}.dim_product
UNION ALL SELECT 'dim_store', COUNT(*) FROM ${hivevar:DW_DB}.dim_store
UNION ALL SELECT 'dim_date', COUNT(*) FROM ${hivevar:DW_DB}.dim_date;

-- Orphan check (must be 0)
SELECT COUNT(*) AS orphan_products
FROM ${hivevar:DW_DB}.fact_sales f LEFT JOIN ${hivevar:DW_DB}.dim_product p ON f.product_key = p.product_key
WHERE p.product_key IS NULL;

-- Business query: revenue by channel & category per year
SELECT d.year, c.channel_name, p.category, ROUND(SUM(f.net_amount),2) AS revenue
FROM ${hivevar:DW_DB}.fact_sales f
JOIN ${hivevar:DW_DB}.dim_date d    ON f.date_key = d.date_key
JOIN ${hivevar:DW_DB}.dim_channel c ON f.channel_key = c.channel_key
JOIN ${hivevar:DW_DB}.dim_product p ON f.product_key = p.product_key
GROUP BY d.year, c.channel_name, p.category
ORDER BY d.year, revenue DESC
LIMIT 20;
