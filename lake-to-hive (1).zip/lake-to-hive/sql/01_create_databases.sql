CREATE DATABASE IF NOT EXISTS ${hivevar:STAGING_DB}
  COMMENT 'Cleaned, conformed data from the 3 sources'
  LOCATION '${hivevar:WAREHOUSE_DIR}/${hivevar:STAGING_DB}.db';

CREATE DATABASE IF NOT EXISTS ${hivevar:DW_DB}
  COMMENT 'Star-schema dimensional warehouse'
  LOCATION '${hivevar:WAREHOUSE_DIR}/${hivevar:DW_DB}.db';
