# Architecture - Multi-Source Data Lake -> Hive Warehouse Pipeline

## The 3 sources

| # | Directory            | Format            | Content                         | Grain                  |
|---|----------------------|-------------------|---------------------------------|------------------------|
| 1 | `source_1_pos`       | CSV (3 files)     | Retail store POS transactions   | 1 row = 1 sale line    |
| 2 | `source_2_ecommerce` | Parquet (2 files) | Online order lines              | 1 row = 1 order line   |
| 3 | `source_3_crm`       | CSV + Parquet     | `customers.csv`, `products.parquet` (master data) | 1 row = 1 customer / SKU |

## Flow

```
 LOCAL LINUX FS                    HDFS (Hadoop, Linux)                         HIVE METASTORE
 ---------------                   --------------------                         --------------
 source_1_pos (CSV)  --+
 source_2_ecom (PQ)  --+--> hdfs dfs -put --> /lake/landing/{pos,ecom,crm}
 source_3_crm (CSV+PQ)-+     (02_consolidate)          |
                                                       | PySpark job 1: clean_transform.py
                                                       |  - trim / case / type casting
                                                       |  - dedupe, reject invalid rows
                                                       |  - guest web orders -> CRM via e-mail
                                                       |  - unify POS + WEB schema
                                                       v
                                       staging.stg_sales  stg_customers  stg_products
                                       staging.rej_sales  rej_sales_no_product
                                                       |
                                                       | PySpark job 2: build_warehouse.py
                                                       |  - surrogate keys, unknown members
                                                       |  - dim_date generation
                                                       v
                                       dw (STAR SCHEMA, Parquet)

                 dim_date    dim_customer
                      \         /
                       fact_sales ---- dim_product
                      /         \
                dim_store      dim_channel
```

## HDFS layout
```
/lake/landing/pos/*.csv
/lake/landing/ecom/*.parquet
/lake/landing/crm/{customers.csv,products.parquet}
/lake/warehouse/staging.db/...
/lake/warehouse/dw.db/...
```

## Star schema
See `star_schema.sql`. Fact grain: one row per sales line (POS or web).
Measures: quantity, unit_price, gross_amount, discount_amount, net_amount, cost_amount, margin_amount.
Special members: `dim_customer.customer_key = -1` (Unknown), `dim_store.store_key = 0` (Online).
`fact_sales` is partitioned by `sale_year`.

## Data-quality rules
- Trim + normalise case on keys, names, e-mails, payment methods
- Duplicate `sale_id` / `customer_id` / `sku` removed
- quantity <= 0, price <= 0, missing timestamp/SKU -> `staging.rej_sales`
- SKU not in CRM catalogue -> `staging.rej_sales_no_product`
- Web guest checkout: `customer_id` recovered by matching lower-cased e-mail with CRM
